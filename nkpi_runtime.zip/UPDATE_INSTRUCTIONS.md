# Install version 9.0.6

Use **NKPI_v906_GitHub_Upload.zip**. Extract the outer download once.

Upload these extracted items at the top level of the existing GitHub repository: `kcn_dual_calculator_app.py`, `nkpi_runtime.zip`, `requirements.txt`, `README.md`, and the `.streamlit` folder containing `config.toml`. Replace matching files. Keep the inner `nkpi_runtime.zip` intact: the launcher automatically unpacks it.

Keep **kcn_dual_calculator_app.py** as Streamlit's main file, in the correct repository and branch. Python **3.12** is the tested version. Reboot the app and refresh the browser; confirm **9.0.6-anatomical-eye** in the footer. Reimport the original report ZIPs, verify the measurements, and calculate.

The 3D viewer opens in a natural whole-eye view. Curvature/thickness overlays, close-up, rotation, reconstruction display and optional cutaway remain available. The tracker keeps a dashed earlier outline and a blue latest region. All model artifacts and measurement calculations are retained from 9.0.5.

Older `nkpi`, `components`, `models`, or `research` folders can remain: the launcher loads the bundled release first. This avoids a separate app-module folder upload. No new API key is required.

If the bundle is missing or does not match the launcher, upload the launcher and `nkpi_runtime.zip` together from the same download and reboot. Do not rename either file or place the new files inside an additional enclosing folder.
