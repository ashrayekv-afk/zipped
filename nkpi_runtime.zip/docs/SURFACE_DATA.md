# Anatomical eye — version 9.0.5

This section supersedes the older display descriptions below. The underlying image and native source contracts are unchanged.

## Continuous presentation shell

The viewer opens on a complete reference globe, iris and transparent corneal shell. Patient shape is available only where source elevation/heights support it. The outer source coordinates are retained; no cone is inferred from NKPI or summary Kmax. Full-eye and close-up views use equal physical axes, with no default height exaggeration.

A separate display mesh fills remaining source-grid holes. The implementation subtracts a centered spherical reference from the available front heights and solves a distance-weighted harmonic continuation at missing nodes while holding supported values fixed. The reference uses the printed BFS when suitable, with radius raised above the illustrative limbus when necessary for a real-valued peripheral sphere. The residual compensates exactly at supported source nodes; this display reference does not replace source heights. Native front/back coordinates are retained at supported nodes. At missing posterior locations, completed thickness offsets the front along its local normal. Where no posterior or thickness data exist, an explicitly reference inner shell is used without a numerical thickness readout.

The full display uses a circular polar mesh (128 angular segments, 76 rings). Bilinear sampling links the source grid to that presentation mesh. Beyond the source aperture, a cubic Hermite transition takes the boundary height residual and a bounded outward slope to a spherical reference at the limbus. This assumes peripheral anatomy and pose; it does not recover measurements. A lower-density display mesh is used while dragging.

## Gap colors and provenance

Available map values remain in their original fields. Additional display-only harmonic fields supply missing interior colors, slightly desaturated. No patient map colors are extrapolated into the peripheral reference cornea. White thickness contours continue to use supported source triangles; they do not use filled values. Source point inspection selects supported original samples; reconstructed gaps have no invented readouts. The optional reconstruction view colors source-supported geometry teal, gap completion amber and reference anatomy gray. Source-supported includes the existing image-derived local-plane smoothing.

Original masks, scalar values, source coverage, numerical map areas, progression domains, cone tracking and NKPI are untouched. A visually complete surface does not imply complete measured coverage. No patient data or new external requests are introduced.

## Shape accuracy

Report elevation plus BFS is an approximate height reconstruction: reference translation/tilt, image quantization and unavailable tissue are not recovered. A more faithful reconstruction requires the actual anterior/posterior surface coordinates and device pachymetry. A smooth filled region is a modeling assumption, not additional clinical evidence. The whole-eye model is not an exact anatomical replica or a surgical planning surface.

The reconstruction uses height as the geometric input. Curvature maps remain overlays, and regional thickness is used for the inner surface where available. These quantities cannot all be treated as exact independent constraints when reconstructed from printed images. See the manufacturer-hosted elevation explanation: https://www.pentacam.com/fileadmin/user_upload/pentacam.de/downloads/publikationen/artikel/2008-Article__Pentacam_An_introduction_understand_elevation_based_topography.pdf .

---

# Patient corneal shape — version 9.0.4

## Surface sources and reference context

**Report-image estimate:** the standard anterior elevation map and printed floating BFS radius from the selected Belin–Ambrósio page, together with that page's thickness map. Front shape is a centered, untilted sphere plus signed elevation, converted from µm to mm. The printed floating BFS translation and tilt are unavailable; this reconstruction explicitly assumes their values. Enhanced/exclusion and difference maps are not substituted. Curvature colors and NKPI scalars never generate height.

A local weighted plane (0.6-mm radius) smooths the elevation and thickness. At least six valid neighboring samples and 50% local readable support are required, with a maximum nearest-sample distance of two sample steps (or 0.25 mm for very fine grids). Large missing areas remain absent from the numerical surface; separate gray reference patches cover them visually. A model requires at least 50% coverage of the sampled central region. The inner surface is an offset along the reconstructed anterior normal by image-derived pachymetry. This is a modeling approximation, not recovery of independently measured posterior geometry. The displayed range is the modeled thickness range, not the device's minimum thickness.

**Native height reconstruction:** matching `kind: measured` / `source: device_numeric_export` anterior and optional posterior `z_mm` grids pass the existing strict `CornealData` schema. Declared physical axes, laterality and z direction are respected. A supplied device thickness map colors the mesh; the renderer does not infer thickness from raw vertical front/back separation. Missing cells and reversed front/back ordering are omitted. Synthetic fixtures cannot enter the patient route.

## Association and display

The selected eye, visit and input snapshot must match the imported source binding. Input changes, source changes, removal of an eye and next-patient reset sever the link. The view never silently uses the other eye or a simulated cone. A labeled standard reference surface can be shown when patient elevation is unavailable. Earlier/latest shapes are independent views, not a registered height subtraction. OD and OS keep the native report orientation (OD temporal at screen left, OS temporal at screen right in front view).

The default uses equal physical axes and true proportions. The optional elevation-emphasis mode described below is explicitly exaggerated. The native or estimated source label is embedded in exported PNGs. The component uses local Canvas rendering and the existing local OCR models; there is no new API or remote AI reader. No report images, calibration grids or geometry are sent to the score server.

## Native export contract

The existing `nkpi-corneal-surface-1` schema requires:
- eye and visit (`OD`/`OS`, `first`/`latest`), measured source and units;
- finite, increasing x/y axes in mm and explicit orientation;
- anterior `z_mm`, optional posterior `z_mm`, optional device `thickness_um`;
- null for missing samples; enough complete cells for rendering.

Use the existing `nkpi-surface-index.json` association workflow in `docs/AUTO_DICOM_IMPORT.md` and numerical conversion documentation. Image-derived estimates have their own internal `nkpi-image-shape-1` contract and are never labeled as device exports.

## Basis and limitations

Reference-sphere radius and placement affect interpretation of elevation maps: https://pmc.ncbi.nlm.nih.gov/articles/PMC4142625/ . The report does not supply all of that pose information. Therefore this supplement is an approximate visualization, not an exact anatomical replica, a validated diagnostic surface, a surgical planning model, or evidence that a region will progress. The calculator's scalar inputs and NKPI are unchanged.

## Diameter confirmation and sample coverage

Version 9.0.1 uses expanded tag crops, cross-crop OCR, numeral-shape recognition and an isolated-digit retry. A valid printed plot size and unit are required. A BFS fitting diameter is never used as the plot diameter. The shape view uses the updated image sampler, including explicitly tracked local-color recovery and rejection of isolated colored-marker artifacts. Modeled coverage includes the further local smoothing/interpolation described above; it is not a direct-data or accuracy percentage.


## Shaded shell renderer (9.0.2)

A local software depth buffer renders front, back and boundary faces with per-vertex lighting. Lighting changes appearance only. The selected image reconstruction still uses the same BFS/elevation geometry and normal-offset thickness model. The default is an oblique shaded corneal shell; a true-scale center section shows both boundaries. Rotation, keyboard rotation, zoom, cutaway, point inspection and PNG export are local. No new external library or service is required.

The display rim is clipped to a 96-sided circle slightly inside the sampled aperture (1.2 grid steps, capped at 8% of the radius). New edge vertices are interpolated only within existing supported triangles. This reduces the staircase appearance without extending data coverage. The displayed diameter is labeled. Larger interior gaps stay open and no iris, sclera or globe is invented. Regional measurements are unaffected.

For image data, anterior/posterior curvature overlays are sampled in the same report x/y frame, with physical diameter conversion and missing values preserved. Radius-to-power conversion matches the existing regional analysis; posterior power is shown as a magnitude. Curvature never generates the mesh. The posterior curvature overlay uses the outer shell for location comparison, not independently recovered posterior geometry. Optional native posterior elevation is displayed only when supplied. The color range describes the available mesh samples, not the whole cornea or scalar extrema.

Summary ARC, PRC, thinnest thickness, Kmax, BAD-D and ARTmax are taken from the bound calculator result and selected visit. They do not distort the surface or create spatial maps. Native heights now use the supported supplied aperture up to a 6-mm radius rather than always cropping to a 3-mm radius. The display still inherits all measurement and sampling limitations; it cannot be called an exact 1:1 replica.

## Reference eye and fallback (9.0.3)

A procedural reference globe (12-mm radius), iris and peripheral reference cornea (7.8-mm sphere radius) surround the central data patch. These are illustrative design dimensions, not fitted patient anatomy or clinical normality cutoffs. Their positions relative to the data patch are assumed. They are rendered independently and never enter spatial analysis or NKPI. Reference geometry has no patient sample-selection IDs.

The central patch retains native heights when available, otherwise the existing report-elevation reconstruction. If that cannot be formed, `kind: reference` provides a standard spherical front surface with available overlays. Available thickness can offset an inner boundary; missing thickness remains missing. Curvature is never converted into arbitrary bump height. This fallback is labeled in the view and saved figure; a reason is retained in the method drawer. It is an illustrative map-bearing cornea, not a patient-specific shape estimate.

**Cornea + eye** provides anatomical context. **Cornea close-up** uses the existing equal-scale central view. Overlay selection does not change geometry. Curvature magnitude, thickness, elevation and confirmed summary values retain distinct meanings. Earlier/latest reconstructions are not animated as a registered deformation.

## Combined view and missing-data presentation (9.0.4)

The default oblique central close-up combines anterior curvature color with white iso-thickness contours labeled in micrometers. Contours are linearly interpolated within triangles whose thickness vertices are finite; they do not cross data gaps. Contour spacing is selected from the available range, at least 10 µm. This is a display interval, not a clinical threshold. Curvature is scaled to the current scan's available range, printed in the legend, so colors alone must not be compared across visits. The inner shell is neutral blue in this mode. Local point selection retains all available overlay values.

Unsupported original-grid triangles receive a separate gray, striped reference patch for visual continuity. Missing vertices use an assumed sphere (printed BFS radius when available, otherwise 7.8 mm) with an average vertical offset; supported boundary vertices are retained. These patches have no measurement or picking IDs, do not enter the patient mesh and never contribute to coverage, NKPI, area or tracker calculations. They are not interpolated patient measurements. Thick tissue-like walls at internal missing boundaries are hidden; explicit cutaway and outer-rim walls remain.

**Emphasize elevation ×3** is available only for image elevation reconstructions and defaults off. Each front/back vertex pair is translated along z by twice its stored elevation deviation, keeping that pair's separation unchanged. This is a visualization aid, not recomputed corneal biomechanics or curvature. Source vertices and values remain unchanged; normals are recomputed only for shading. The plot and saved figure visibly label the exaggeration. The true-scale inset uses the original grid row nearest the thinnest supported sample (central row if thickness is absent). It never joins nonadjacent source samples. Its location need not equal the report’s scalar minimum. No cone is inserted when the available source does not show one. Reference-only and native-height modes do not expose this report-elevation option.
